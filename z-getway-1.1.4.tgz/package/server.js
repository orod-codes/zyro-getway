#!/usr/bin/env node
'use strict';

require('./src/index').start();
